﻿/*Begining of Auto generated code by Atmel studio */
#include <Arduino.h>

/*End of auto generated code by Atmel studio */

#include <PWM.h>
//Beginning of Auto generated function prototypes by Atmel Studio
void setup();
void loop ();
void EnablePins(int Hex);
void InputPinConfigs(int Hex);
void AttachInts(int A,int B,int C);
void HallCheck();
void SerialPrintValue(char str[],int value);
void SerialCheck();
void Drive(bool Forwd);
void PID();

//End of Auto generated function prototypes by Atmel Studio


#define En3 26  // sürücünün enable pinleri
#define En2 24
#define En1 22

#define In3 7   // sürücünün input pinleri
#define In2 6
#define In1 5

#define HC  21  //Interrupt 2
#define HA  20  //Interrupt 3
#define HB  19  //Interrupt 4

int32_t frequency = 64000;
int32_t dutyCommon = 50; // Around 80% of the maximum

volatile bool HallA = LOW;
volatile bool HallB = LOW;
volatile bool HallC = LOW;

float Kp=0.5 ;
float Kd=0.002;
float Ki_term=0.0;
float Ki=0.2;
float Ki_sat=40;

int state=0;
int prev_state=0;
int state_temp=0;
int num_of_turn = 0;
int ref_rpm=0;
int state_change=0;

unsigned long prev_time=0;
long delta_t=0;

bool CanDriveMotor=false;
bool driveDir=false;

int blink;
int pin= 25;
int val=0;

void setup()
{
	pinMode(En3, OUTPUT);
	pinMode(En2, OUTPUT);
	pinMode(En1, OUTPUT);
	
	pinMode(In3, OUTPUT);
	pinMode(In2, OUTPUT);
	pinMode(In1, OUTPUT);
	
	pinMode(HA, INPUT);
	pinMode(HB, INPUT);
	pinMode(HC, INPUT);

	//Start Serial Interface
	Serial.begin(115200);
	Serial.println("Serial Interface is ready.");
	
	InitTimersSafe(); // timerları initilize eder

	bool success1 = SetPinFrequencySafe(In1, frequency);  //input PWM sinyallerinin frekanslarını ayarlar
	bool success2 = SetPinFrequencySafe(In2, frequency);
	bool success3 = SetPinFrequencySafe(In3, frequency);
	if(success1 &&success2 &&success3 )
	{
		Serial.println("Frequency chance has been completed");

		EnablePins(6);
		InputPinConfigs(6);
		AttachInts(2,3,4);  // Hall sensorlerini interrupt olarak koda attach eder
		HallCheck();    // Mevcut Hall dataları ile mevcut state bulunur
		digitalWrite(pin, HIGH);
	}
}

void loop ()
{
	
	if(CanDriveMotor)
	{
		PID();
		Drive(driveDir);
		//Serial.println(num_of_turn);
	}	
	//if(Serial.available())
	if(!CanDriveMotor)
	{Serial.println("DONME!");
	SerialCheck();  // turn sayısı gir
	}
	/*
	delay(2);
	if(blink>100)
	{
	blink=0;
	val=digitalRead(pin);
	if(val==HIGH)
	digitalWrite(25, LOW);
	else
	digitalWrite(25, HIGH);
	}
	blink++;
	*/
	
	
}


void EnablePins(int Hex)//başlangıçta enable pinlerini ayarlar
{
	if(Hex&1)     digitalWrite(En1, HIGH);
	else          digitalWrite(En1, LOW);
	if(Hex&2)     digitalWrite(En2, HIGH);
	else          digitalWrite(En2, LOW);
	if(Hex&4)     digitalWrite(En3, HIGH);
	else          digitalWrite(En3, LOW);
}


void InputPinConfigs(int Hex)//başlangıçta input pinlerini ayarlar
{
	if(Hex&1)     digitalWrite(In1, HIGH);
	else          digitalWrite(In1, LOW);
	if(Hex&2)     digitalWrite(In2, HIGH);
	else          digitalWrite(In2, LOW);
	if(Hex&4)     digitalWrite(In3, HIGH);
	else          digitalWrite(In3, LOW);

}


void AttachInts(int A,int B,int C)//Interrupt pinleri her değiştiğinde Hallcheck fonksiyonunu çağırır
{
	attachInterrupt(A, HallCheck, CHANGE);
	attachInterrupt(B, HallCheck, CHANGE);
	attachInterrupt(C, HallCheck, CHANGE);
}


void HallCheck()//Hall sensörden gelen 3 biti kontrol edip state i hesaplar
{
	HallA=digitalRead(HA);
	HallB=digitalRead(HB);
	HallC=digitalRead(HC);
	state_temp=0;
	if(HallC) state_temp+=1;
	if(HallB) state_temp+=2;
	if(HallA) state_temp+=4;
	state = state_temp;
	Serial.print("state: ");
	Serial.println(state);
	
}


void SerialPrintValue(char str[],int value)//kullanmıyorum
{
	Serial.print(str);
	Serial.println(value);
}



void SerialCheck()//Seri porttan gelecek turn sayısını kontrol et
{	
	
	int turn=Serial.parseInt();
	//Serial.println("Enter positive rpm value ");

	
	  if(Serial.read()=='\n')
	  {	

	if(turn==0)
	{
		CanDriveMotor=false;
	}
	else if(turn>0)
	{
		CanDriveMotor=true;
		driveDir=true;
	}
	else if(turn<0)
	{
		CanDriveMotor=true;
		driveDir=false;
		turn = - turn;
	}
	
	if (CanDriveMotor)
	{
		
		num_of_turn=turn;
		
		ref_rpm=10000;
		state_change = ((6 * num_of_turn)-1);
	}
	else
	{
		dutyCommon = 0;
	}
	Serial.println();
	Serial.println();
	Serial.print("number of turn: ");
	Serial.println(num_of_turn);
	Serial.println();
	Serial.println();
	 }
}


void Drive(bool Forwd)
{
	 Serial.println("drive");
	int En=0;
	
	if(!(state==6 || state==1)) En+=1;
	if(!(state==4 || state==3)) En+=2;
	if(!(state==5 || state==2)) En+=4;
	
	EnablePins(En);
	
	if(Forwd)
	{
		if(state==5 || state==4)  pwmWrite(In1, 0);
		else pwmWrite(In1, dutyCommon);
		if(state==6 || state==2)   pwmWrite(In2, 0);
		else pwmWrite(In2, dutyCommon);
		if(state==3 || state==1)   pwmWrite(In3, 0);
		else pwmWrite(In3, dutyCommon);
	}
	else
	{
		
		if(state==5 || state==4)   pwmWrite(In1, dutyCommon);
		else pwmWrite(In1, 0);
		if(state==6 || state==2)   pwmWrite(In2, dutyCommon);
		else pwmWrite(In2, 0);
		if(state==3 || state==1)   pwmWrite(In3, dutyCommon);
		else pwmWrite(In3, 0);

	}
}



void PID()

{
	
	if(prev_state!=state)
	{   
		
		prev_state=state;
		unsigned long now= micros();
		delta_t=now-prev_time;
		prev_time=now;
		
		state_change=--state_change;
		
		Serial.print("Delta Time: ");
		char buffer [50];
		int n=sprintf (buffer, "%lu", delta_t);
		Serial.println(buffer);
		
		float rpm_cur=(1000000.0f/(float(delta_t*6)))*60.0f;
		SerialPrintValue("rpm_cur: ",rpm_cur);
		
		float dt= delta_t/1000000.0f;
		long error=(ref_rpm-rpm_cur);
		float KP_term= Kp*(error);
		Ki_term += Ki*(error)*dt;
		
		if(Ki_term>Ki_sat)  Ki_term=Ki_sat;  //saturation control
		else if(Ki_term<-Ki_sat) Ki_term=-Ki_sat;
		
		float KD_term= Kd*(error)/dt;
		
		
		SerialPrintValue("KP: ",KP_term);
		SerialPrintValue("KI: ",Ki_term);
		SerialPrintValue("KD: ",KD_term);
		SerialPrintValue("state_change: ",state_change);
		
		if (state_change>0)
		{  dutyCommon = (KP_term+Ki_term+KD_term)/130;
			if(delta_t >250000)
			dutyCommon = 50; //AYAR ÇEKCEN
			if(state_change < 3)
			{
				dutyCommon = dutyCommon/2;
			}
		SerialPrintValue("Duty: ", dutyCommon);}
		else
		{
			CanDriveMotor = false;
			
		}
	}
	else
	{
		//Serial.println("State Change does not occur");
	}
}

﻿/*Begining of Auto generated code by Atmel studio */
#include <Arduino.h>

/*End of auto generated code by Atmel studio */

  

#include <PWM.h>
//Beginning of Auto generated function prototypes by Atmel Studio
void setup();
void loop();
void SerialCheck();
void EnablePins(int Hex);
void InputPinConfigs(int Hex);
void SerialPrintValue(char str[],int value);
void FreqChange(int32_t freq);
void AttachInts(int A,int B,int C);
void HallCheck();
void Drive(bool Forwd,int32_t dutyCommon);
void CalculateDuties();
int SetDuty(int du);
//End of Auto generated function prototypes by Atmel Studio


//Parameters


#define En3 26
#define En2 24
#define En1 22

#define In3 7   //Yellow Out3
#define In2 6
#define In1 5

#define HA  21  //Interrupt 2 
#define HB  20  //Interrupt 3
#define HC  19  //Interrupt 4

#define LedPin 13

#define DutyLimitMax 50 // Around 80% of the maximum

//Control Parameters

#define stallfirst 250 // ms
#define stallsecond 1000 //ms
#define stallDuty 40

float Kp=0.5 ;
float Kd=0.002;
float Ki_term=0.0;
float Ki=0.2;
float Ki_sat=40;


//Variables

int32_t frequency = 64000; //frequency (in Hz)
int32_t dutyRatio = 0; //frequency (in Hz)

int32_t dutyRat=0;
int32_t freq=0;

volatile bool HallA = LOW;
volatile bool HallB = LOW;
volatile bool HallC = LOW;

int prev_state=0;
unsigned long prev_time=0;
long delta_t=0;
int state= 0;
volatile int state_temp=0;

float rpm_ref=0.0f;
long referenceWait=0;

bool CanDriveMotor=false;
bool driveDir=false;
int forwInt=0 , backwInt=1;

void setup()
{

  
  pinMode(LedPin, OUTPUT);
  digitalWrite(LedPin, LOW);
  
  pinMode(En3, OUTPUT);
  pinMode(En2, OUTPUT);
  pinMode(En1, OUTPUT);
  
  pinMode(In3, OUTPUT);
  pinMode(In2, OUTPUT);
  pinMode(In1, OUTPUT);
  
  pinMode(HA, INPUT);
  pinMode(HB, INPUT);
  pinMode(HC, INPUT);

  //Start Serial Interface
  Serial.begin(115200);
  Serial.println("Hello dear last BLDC-motor-bender");
  
  //initialize all timers except for 0, to save time keeping functions
  InitTimersSafe(); 

  //sets the frequency for the specified pin
  bool success1 = SetPinFrequencySafe(In1, frequency);
  bool success2 = SetPinFrequencySafe(In2, frequency);
  bool success3 = SetPinFrequencySafe(In3, frequency);
  
  //if the pin frequency was set successfully, turn pin 13 on
  if(success1 &&success2 &&success3 ) {
    Serial.println("Frequency chance has been completed");

    EnablePins(6);
    InputPinConfigs(6);
    
    //Indicate Timers are okay
    digitalWrite(LedPin, HIGH);
    
    //Attach interrupts and read the initial configuration of the halls
    AttachInts(2,3,4);
    HallCheck();
    
  }
  prev_time=micros();
}

void loop()
{
  if(CanDriveMotor)
  {
  CalculateDuties();
  Drive(driveDir, dutyRatio);
  }
  //Make serial check  
  if(Serial.available())  SerialCheck();
}


void SerialCheck()
{  
//  delay(1);
  int rpm100=Serial.parseInt();

  if(Serial.read()=='\n')
  {

     if(rpm100==0)
     {
        CanDriveMotor=false; 
     }
     else if(rpm100>0)
     {
       CanDriveMotor=true;
	   driveDir=true;
     }
     else if(rpm100<0)
     {
       CanDriveMotor=true;
	   driveDir=false;
        rpm100 = - rpm100;
     }
	 
      if (CanDriveMotor) 
      {
      	rpm_ref=rpm100/10.0f;
         prev_time=micros();
      }
      else
      {
        rpm_ref=0;
      }
      Serial.println();
      Serial.println();
     Serial.print("RPM Reference: ");  
     Serial.println(rpm_ref); 
	
    
    Serial.println();
    Serial.println();
  }
  
}

//Input the desired config at Hexadecimal number 
void EnablePins(int Hex)
{
   if(Hex&1)     digitalWrite(En1, HIGH);
   else          digitalWrite(En1, LOW);
   if(Hex&2)     digitalWrite(En2, HIGH);
   else           digitalWrite(En2, LOW);
   if(Hex&4)     digitalWrite(En3, HIGH);
   else           digitalWrite(En3, LOW);
}
//Input the desired config at Hexadecimal number 
void InputPinConfigs(int Hex)
{
   if(Hex&1)     digitalWrite(In1, HIGH);
   else           digitalWrite(In1, LOW);
   if(Hex&2)     digitalWrite(In2, HIGH);
   else           digitalWrite(In2, LOW);
   if(Hex&4)     digitalWrite(In3, HIGH);
   else           digitalWrite(In3, LOW);

}
void SerialPrintValue(char str[],int value)
{
  Serial.print(str);  
  Serial.println(value); 
  
}
void FreqChange(int32_t freq){
 //sets the frequency for the specified pin
  bool success1 = SetPinFrequencySafe(In1, freq);
  bool success2 = SetPinFrequencySafe(In2, freq);
  bool success3 = SetPinFrequencySafe(In3, freq); 
   if(success1 &&success2 &&success3 ) 
   {
    Serial.println("Frequancy change has been completed") ;
   }
}

void AttachInts(int A,int B,int C)
{
   attachInterrupt(A, HallCheck, CHANGE);
   attachInterrupt(B, HallCheck, CHANGE);
   attachInterrupt(C, HallCheck, CHANGE);
  
}

void HallCheck()
{
  HallA=digitalRead(HA);
  HallB=digitalRead(HB);
  HallC=digitalRead(HC);
  state_temp=0;
  if(HallC) state_temp+=1;
  if(HallB) state_temp+=2;
  if(HallA) state_temp+=4;  
  
  Serial.print("state_temp: ");  
  Serial.println(state_temp);
  
  //Check if the sequence is correct, then assign it
  state=state_temp;
}

void Drive(bool Forwd,int32_t dutyCommon)
{
  //Enable Signals
  int En=0;
  
    //Calc A
  if(!(state==6 || state==1)) En+=1;
  if(!(state==4 || state==3)) En+=2;
  if(!(state==5 || state==2)) En+=4;
  
  //SerialPrintValue("Enable in Drive: ",En);
  
  EnablePins(En);
  
  if(Forwd)
  {
  if(state==5 || state==4)   pwmWrite(In1, 0);
  else pwmWrite(In1, dutyCommon);
  if(state==6 || state==2)   pwmWrite(In2, 0);
  else pwmWrite(In2, dutyCommon);
  if(state==3 || state==1)   pwmWrite(In3, 0);
  else pwmWrite(In3, dutyCommon);
  }
  else
  {
      
  if(state==5 || state==4)   pwmWrite(In1, dutyCommon);
  else pwmWrite(In1, 0);
  if(state==6 || state==2)   pwmWrite(In2, dutyCommon);
  else pwmWrite(In2, 0);
  if(state==3 || state==1)   pwmWrite(In3, dutyCommon);
  else pwmWrite(In3, 0);

  }
  
  //Input Signals

 
}
void CalculateDuties()
{
  if(prev_state!=state)
  {
   prev_state=state;
   unsigned long now= micros();
   delta_t=now-prev_time;
   prev_time=now;
   
   Serial.print("Delta Time: ");
   char buffer [50];
   int n=sprintf (buffer, "%lu", delta_t);
   Serial.println(buffer);
   
   float rpm_cur=(1000000.0f/(float(delta_t*6)))*60.0f;
   SerialPrintValue("rpm_cur: ",rpm_cur);
   
   float dt= delta_t/1000000.0f;
   long error=(rpm_ref-rpm_cur)/10;
   float KP_term= Kp*(error);
   Ki_term += Ki*(error)*dt;
   //Saturation check 
   if(Ki_term>Ki_sat)  Ki_term=Ki_sat;
   else if(Ki_term<-Ki_sat) Ki_term=-Ki_sat;
   
   float KD_term= Kd*(error)/dt;
   dutyRatio= SetDuty(int(KP_term+Ki_term+KD_term));
   
   SerialPrintValue("Duty: ",dutyRatio);
   SerialPrintValue("KP: ",KP_term);
   SerialPrintValue("KI: ",Ki_term);
   SerialPrintValue("KD: ",KD_term);
   
  }
  
  //Or there occurs stall
  //In order to decrease stall time, i start with a initial value that is expected to move the rotor. 
  //If it does'nt move, then the PID kicks in
  else if((micros()-prev_time)/1000>stallfirst)
  {
   // Serial.println("Stall...!! ");
    dutyRatio=SetDuty(stallDuty);
   }
  
}
int SetDuty(int du)
{
 if(du >DutyLimitMax) return DutyLimitMax;
 else if(du<0)  return 0;
  else   return du; 
  
  
}

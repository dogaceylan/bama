﻿/*Begining of Auto generated code by Atmel studio */
#include <Arduino.h>

/*End of auto generated code by Atmel studio */


//Beginning of Auto generated function prototypes by Atmel Studio
void setup();
void loop ();
void EnablePins(int Hex);
void InputPinConfigs(int Hex2);
void AttachInts(int A,int B,int C);
void HallCheck();
void SerialPrintValue(char str[],int value);
void SerialCheck();
void Drive(bool Forwd);
void PID();
//End of Auto generated function prototypes by Atmel Studio


  int turn;
  int sayi;
  int Hex2;
  int Hex;

  //#define En3 26  // sürücünün enable pinleri
  //#define En2 24
  //#define En1 22
  
   #define En3 47  // sürücünün enable pinleri
   #define En2 48
   #define En1 49
   
  #define In3 8   // sürücünün input pinleri
  #define In2 7
  #define In1 6
  
  #define HA  21  //Interrupt 2 
  #define HB  20  //Interrupt 3
  #define HC  19  //Interrupt 4
  
  int32_t dutyCommon = 50; // Around 80% of the maximum
  
  volatile bool HallA = LOW;
  volatile bool HallB = LOW;
  volatile bool HallC = LOW;
  
  float Kp=0.5 ;
  float Kd=0.002;
  float Ki_term=0.0;
  float Ki=0.2;
  float Ki_sat=40;

  int state=0;
  int prev_state=0;
  int state_temp=0;
  int num_of_turn = 0;
  int ref_rpm=0;
  int state_change=0;
 
  unsigned long prev_time=0;
  long delta_t=0;
  
  bool CanDriveMotor=false;
  bool driveDir=false;
  
  void setup()
{
  Serial2.begin(9600);  // Begin the serial monitor at 9600bps

 
  pinMode(En3, OUTPUT);
  pinMode(En2, OUTPUT);
  pinMode(En1, OUTPUT);
  
  pinMode(In3, OUTPUT);
  pinMode(In2, OUTPUT);
  pinMode(In1, OUTPUT);
  
  pinMode(HA, INPUT);
  pinMode(HB, INPUT);
  pinMode(HC, INPUT);

  //Start Serial Interface
//  Serial.begin(115200);
  Serial2.println("Serial Interface is ready.");
 
  
  int myEraser = 7;     //7=111, reset prescaler pins
  TCCR0B &= ~myEraser;
  TCCR1B &= ~myEraser;  //pin 5, 3, 2 (ben 5i kullanıyom)
  TCCR2B &= ~myEraser;  //pin 6, 7, 8 (ben 6 ve 7yi kullanıyom)
  TCCR3B &= ~myEraser;  //pin 5, 3, 2 (ben 5i kullanıyom)
  TCCR4B &= ~myEraser;

  int myPrescaler = 1;
           // 31000 Hz ayarla.
  TCCR0B |= myPrescaler;
  TCCR1B |= myPrescaler;
  TCCR2B |= myPrescaler;
  TCCR3B |= myPrescaler;
  TCCR4B |= myPrescaler;


    AttachInts(2,3,4);  // Hall sensorlerini interrupt olarak koda attach eder
    HallCheck();    // Mevcut Hall dataları ile mevcut state bulunur 
      EnablePins(0);
      InputPinConfigs(0);
}

  void loop ()
{
	
	
  if(CanDriveMotor)
  {
	 // Serial2.println("hohohohohoho");
    PID();
    Drive(driveDir);    
  } 
  else
  {
      EnablePins(0);
      InputPinConfigs(0);
  }
//if(Serial.available())  
  SerialCheck();  // turn sayısı gir

}

 

  void EnablePins(int Hex)
{
   if(Hex&1)     digitalWrite(En1, HIGH);
   else          digitalWrite(En1, LOW);
   if(Hex&2)     digitalWrite(En2, HIGH);
   else          digitalWrite(En2, LOW);
   if(Hex&4)     digitalWrite(En3, HIGH);
   else          digitalWrite(En3, LOW);
}


  void InputPinConfigs(int Hex2)
{
   if(Hex2&1)     digitalWrite(In1, HIGH);
   else          digitalWrite(In1, LOW);
   if(Hex2&2)     digitalWrite(In2, HIGH);
   else          digitalWrite(In2, LOW);
   if(Hex2&4)     digitalWrite(In3, HIGH);
   else          digitalWrite(In3, LOW);

}


void AttachInts(int A,int B,int C)
{
   attachInterrupt(A, HallCheck, CHANGE);
   attachInterrupt(B, HallCheck, CHANGE);
   attachInterrupt(C, HallCheck, CHANGE);
}


  void HallCheck()
{
  HallA=digitalRead(HA);
  HallB=digitalRead(HB);
  HallC=digitalRead(HC);
  state_temp=0;
  if(HallC) state_temp+=1;
  if(HallB) state_temp+=2;
  if(HallA) state_temp+=4;  
  state = state_temp;
  
  //Serial2.print("state: ");  
  //Serial2.println(state);

}


 void SerialPrintValue(char str[],int value)
{
  Serial.print(str);  
  Serial.println(value); 
}



void SerialCheck()
{

	if (Serial2.available() && CanDriveMotor==false) //Serial2.available sıkıntı olabilir
	{
		
		 Serial2.println("SAYI GIRDIN"); 
		turn = Serial2.read();
		Serial2.println(turn);

		if(turn==0)
		{
			CanDriveMotor=false;
		}
		else if(turn>0)
		{ //Serial2.println("+++++++++"); 
			CanDriveMotor=true;
			driveDir=true;
		}
		else if(turn<0)
		{//Serial2.println("--------"); 
			CanDriveMotor=true;
			driveDir=false;
			turn = - turn;
		}
		
		if (CanDriveMotor)
		{
			
			num_of_turn=turn;
			
			ref_rpm=10000;
			state_change = ((6 * num_of_turn)-1);
		}
		else
		{
			dutyCommon = 0;
		}


/*
 void SerialCheck()
{  

     if (bluetooth.available() && CanDriveMotor==false)
  {
   turn = bluetooth.read();
    Serial.println(turn);

     if(turn==0)
     {
        CanDriveMotor=false; 
     }
     else if(turn>0)
     {
       CanDriveMotor=true;
	   driveDir=true;
     }
     else if(turn<0)
     {
       CanDriveMotor=true;
	   driveDir=false;
        turn = - turn;
     }
	 
      if (CanDriveMotor) 
      {
         
         num_of_turn=turn;
         
         ref_rpm=10000;
         state_change = ((6 * num_of_turn)-1);
      }
      else
      {
        dutyCommon = 0; 
      }
	  
	  */


 /*     Serial.println();
      Serial.println();
      Serial.print("number of turn: ");  
      Serial.println(num_of_turn); 
      Serial.println();
      Serial.println();*/
 
 
   
}
}

  void Drive(bool Forwd)
{//Serial2.println("driveeee"); 
  int En=0;
  
  if(!(state==6 || state==1)) En+=1;
  if(!(state==4 || state==3)) En+=2;
  if(!(state==5 || state==2)) En+=4;
  
  EnablePins(En);
  
  if(Forwd)
  {
  if(state==5 || state==4)   analogWrite(In1, 0);
  else analogWrite(In1, 100);
  if(state==6 || state==2)   analogWrite(In2, 0);
  else analogWrite(In2,100);
  if(state==3 || state==1)   analogWrite(In3, 0);
  else analogWrite(In3,100);
  }
  else
  {
      
  if(state==5 || state==4)   analogWrite(In1, 80);
  else analogWrite(In1, 0);
  if(state==6 || state==2)   analogWrite(In2, 80);
  else analogWrite(In2, 0);
  if(state==3 || state==1)   analogWrite(In3, 80);
  else analogWrite(In3, 0);

  }
}
  
  
  
void PID()

{
  if(prev_state!=state)
  {//Serial2.println("lalala");
   prev_state=state;
   unsigned long now= micros();
   delta_t=now-prev_time;
   prev_time=now;
   
   state_change=--state_change;
   
   Serial.print("Delta Time: ");
   char buffer [50];
   int n=sprintf (buffer, "%lu", delta_t);
   Serial.println(buffer);
   
   float rpm_cur=(1000000.0f/(float(delta_t*6)))*60.0f;
   SerialPrintValue("rpm_cur: ",rpm_cur);
   
   float dt= delta_t/1000000.0f;
   long error=(ref_rpm-rpm_cur);
   float KP_term= Kp*(error);
   Ki_term += Ki*(error)*dt;
   
   if(Ki_term>Ki_sat)  Ki_term=Ki_sat;  //saturation control
   else if(Ki_term<-Ki_sat) Ki_term=-Ki_sat;
   
   float KD_term= Kd*(error)/dt;
   
   
   SerialPrintValue("KP: ",KP_term);
   SerialPrintValue("KI: ",Ki_term);
   SerialPrintValue("KD: ",KD_term);
   Serial2.println(state_change);
   
   if (state_change>0)
{  dutyCommon = (KP_term+Ki_term+KD_term)/130;
    if(delta_t >250000)
   dutyCommon = 50; //AYAR ÇEKCEN
    if(state_change < 3)
    {
    dutyCommon = dutyCommon/2; 
    }
   SerialPrintValue("Duty: ", dutyCommon);} 
   else
   {
   CanDriveMotor = false;
   
   }
  }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace BLDC_motor_control
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void COM_search_Click(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            string[] ports = SerialPort.GetPortNames();
            foreach (string port in ports)//her isimi ayrı ayrı komboboxa ekle
            {
                comboBox1.Items.Add(port);
            }
        }

        string t;
        string sp;

        private void send_data_Click(object sender, EventArgs e)
        {
            t = comboBox1.Text.ToString();
            serial(t);
        }

        
        void serial(string Port_name)
        {
            System.IO.Ports.SerialPort sp = new SerialPort(Port_name, 115200, Parity.None, 8, StopBits.One);
            sp.Open();
   /*         int numVal = Int32.Parse(textBox1.Text);
            byte[] buffer = new byte[] { Convert.ToByte(numVal) };
            if (sp.IsOpen)
            sp.Write(buffer, 0, 1);
            byte result = Convert.ToByte(numVal);
            if (sp.IsOpen)
            {
            sp.Write(new byte[] { result }, 0, 1);
            }*/
            if (sp.IsOpen)
                sp.Write(textBox1.Text);
            sp.Close();
        }


    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using ZedGraph;


namespace getdatafromIMU
{
    public partial class Form1 : Form
    {
        
        public string msg; //msg seri porttan gelen data olacak
        private const char CHAR_SEPARATOR = ';';
        public int counter = 0;
        GraphPane paneIMU;
        GraphPane paneIMU2;
        PointPairList[] dataIMU = new PointPairList[2];
        
            
        public Form1()
        {
            InitializeComponent();
            
            paneIMU = graphIMU.GraphPane;
            paneIMU.Title = "Shank Angle Graph";
            paneIMU.XAxis.Title = "Time (per 20 ms)";
            paneIMU.YAxis.Title = "IMU degree";

            paneIMU2 = graphIMU2.GraphPane;
            paneIMU2.Title = "Thigh Angle Graph";
            paneIMU2.XAxis.Title = "Time (per 20 ms)";
            paneIMU2.YAxis.Title = "IMU degree";

            dataIMU[0] = new PointPairList();
            dataIMU[1] = new PointPairList();

        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            string[] ports = SerialPort.GetPortNames();
            foreach (string port in ports)
            {
                comboBox1.Items.Add(port);
            }
        }
        //

        string t;

        private void button2_Click(object sender, EventArgs e)
        {
            t = comboBox1.Text.ToString();

            serial(t);
        }

        SerialPort sp;
        void serial(string Port_name)
        {
            try
            {
                sp = new SerialPort(Port_name, 9600, Parity.None, 8, StopBits.One);
                sp.DataReceived += DataReceivedHandler;
                sp.RtsEnable = true;
                sp.Open();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void Sp_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            MessageBox.Show(msg.ToString());
        }

        //
        private void DataReceivedHandler(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                int[] dummyAcc = new int[2];

                msg = sp.ReadLine();

                if (msg != String.Empty)
                {
                    string[] dummyStr = msg.Split(CHAR_SEPARATOR);

                    //Invoke(new Action(() => zedGraphControl1.Width = Convert.ToInt16(msg)));
                    if(dummyStr.Length == 2)
                    { 
                        Invoke(new Action(() =>
                        {
                            richTextBox1.Text = dummyStr[0] + '\n' + richTextBox1.Text;
                            richTextBox2.Text = dummyStr[1] + richTextBox2.Text;
                        }
                        ));
                    }
                    else
                    {
                        MessageBox.Show("String 2 parça değil");
                    }


                    //String dummyS = (String)(msg.Clone());
                    //String[] s = dummyS.Split(CHAR_SEPARATOR.ToCharArray());
                    //int.TryParse(s[0], out  dummyAcc[0]);

                    dummyAcc[0] = Convert.ToInt16(dummyStr[0]);
                    dataIMU[0].Add(counter, dummyAcc[0]);
                    dummyAcc[1] = Convert.ToInt16(dummyStr[1]);
                    dataIMU[1].Add(counter, dummyAcc[1]);
                }

                counter++;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

// Artık msg de IMU dataları kayıtlı. Grafik işine başla       

        private void button3_Click(object sender, EventArgs e)
        {
            // Setup the graph
            //SetSize();
            CreateGraph(graphIMU);

            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            //sp.Close();
        }



        private void SetSize()
        {
            graphIMU.Location = new Point(10, 10);
            // Leave a small margin around the outside of the control
            graphIMU.Size = new Size(ClientRectangle.Width - 20, ClientRectangle.Height - 20);
        }



        private void CreateGraph(ZedGraphControl graphIMU)
        {

            timer1.Start();

        }

        private void timer1_Tick(object sender, EventArgs e)
        {        
            try
            {
                graphIMU.GraphPane.CurveList.Clear();
                graphIMU2.GraphPane.CurveList.Clear();

                LineItem lineIMU = paneIMU.AddCurve("IMU", dataIMU[0], Color.Red, SymbolType.None);
                LineItem lineIMU2 = paneIMU2.AddCurve("IMU", dataIMU[1], Color.Blue, SymbolType.None);

                graphIMU.AxisChange();
                graphIMU.Invalidate();

                graphIMU2.AxisChange();
                graphIMU2.Invalidate();
            }
            catch { }
        }

        //-----------------------------------------------------------------------------------

        private void Form1_Load(object sender, EventArgs e)
        {

            // Size the control to fill the form with a margin
            // Setup the graph
            //CreateGraph(zedGraphControl1)
            //SetSize();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            timer1.Stop();
            if (sp != null && sp.IsOpen)
            {
                sp.RtsEnable = false;
            }
        }
    }
}

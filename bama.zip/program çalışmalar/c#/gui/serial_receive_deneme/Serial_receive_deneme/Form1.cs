﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace Serial_receive_deneme
{
    public partial class Form1 : Form
    {

        public string msg;
        public Form1()
        {
            InitializeComponent();
        }

        private void search_available_ports_btn_Click(object sender, EventArgs e)
        {
            string[] ports = SerialPort.GetPortNames();
            foreach (string port in ports)
            {
                comboBox1.Items.Add(port);
            }
        }
        //

        string t;
        private void readbtn_Click(object sender, EventArgs e)
        {
            
            
            t = comboBox1.Text.ToString();

            serial (t);



        }
        //
        //method
        SerialPort sp;
        void serial (string Port_name)
        {
            sp= new SerialPort(Port_name, 9600, Parity.None,8,StopBits.One);
            sp.DataReceived += new SerialDataReceivedEventHandler (DataReceivedHandler);
            sp.Open();
        }
        //
        private void DataReceivedHandler( object sender, SerialDataReceivedEventArgs e)
        {
            SerialPort sp = (SerialPort) sender;
            
            try
            {
           // msg = sp.ReadExisting();
                msg= sp.ReadLine();
            }
                catch { }
           if (msg != String.Empty)
            {
                
                    Invoke(new Action(() => richTextBox1.AppendText(msg)));
                
               
           }

            
        }
    }
}
